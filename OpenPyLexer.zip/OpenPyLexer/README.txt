Thanks for using OpenPyLexer.
I hope it is useful for you when creating your Python languages.
Feel free to show me any work you have done with it.
Bye!